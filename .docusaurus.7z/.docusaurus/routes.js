import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/__docusaurus/debug',
    component: ComponentCreator('/__docusaurus/debug', '96d'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/config',
    component: ComponentCreator('/__docusaurus/debug/config', '039'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/content',
    component: ComponentCreator('/__docusaurus/debug/content', '2fa'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/globalData',
    component: ComponentCreator('/__docusaurus/debug/globalData', '772'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/metadata',
    component: ComponentCreator('/__docusaurus/debug/metadata', '029'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/registry',
    component: ComponentCreator('/__docusaurus/debug/registry', '793'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/routes',
    component: ComponentCreator('/__docusaurus/debug/routes', '075'),
    exact: true
  },
  {
    path: '/blog',
    component: ComponentCreator('/blog', '5da'),
    exact: true
  },
  {
    path: '/blog/2024-02-16T04:30',
    component: ComponentCreator('/blog/2024-02-16T04:30', '6ac'),
    exact: true
  },
  {
    path: '/blog/2024-02-16T19:46',
    component: ComponentCreator('/blog/2024-02-16T19:46', 'f51'),
    exact: true
  },
  {
    path: '/blog/2024-02-22T14:30',
    component: ComponentCreator('/blog/2024-02-22T14:30', '356'),
    exact: true
  },
  {
    path: '/blog/2024-02-29T03:02',
    component: ComponentCreator('/blog/2024-02-29T03:02', 'fab'),
    exact: true
  },
  {
    path: '/blog/2024-03-05T09:40',
    component: ComponentCreator('/blog/2024-03-05T09:40', 'c86'),
    exact: true
  },
  {
    path: '/blog/2024-05-10T04:00',
    component: ComponentCreator('/blog/2024-05-10T04:00', '5f1'),
    exact: true
  },
  {
    path: '/blog/2024-08-30T23:00',
    component: ComponentCreator('/blog/2024-08-30T23:00', 'a29'),
    exact: true
  },
  {
    path: '/blog/2024-11-26T15:46',
    component: ComponentCreator('/blog/2024-11-26T15:46', 'b46'),
    exact: true
  },
  {
    path: '/blog/2024-11-28T04:31',
    component: ComponentCreator('/blog/2024-11-28T04:31', 'c93'),
    exact: true
  },
  {
    path: '/blog/archive',
    component: ComponentCreator('/blog/archive', '796'),
    exact: true
  },
  {
    path: '/blog/tags',
    component: ComponentCreator('/blog/tags', 'ec6'),
    exact: true
  },
  {
    path: '/blog/tags/技术',
    component: ComponentCreator('/blog/tags/技术', 'e8d'),
    exact: true
  },
  {
    path: '/blog/tags/开发',
    component: ComponentCreator('/blog/tags/开发', '808'),
    exact: true
  },
  {
    path: '/blog/tags/鸣潮',
    component: ComponentCreator('/blog/tags/鸣潮', '1b7'),
    exact: true
  },
  {
    path: '/blog/tags/输入法皮肤',
    component: ComponentCreator('/blog/tags/输入法皮肤', '4de'),
    exact: true
  },
  {
    path: '/blog/tags/闲谈',
    component: ComponentCreator('/blog/tags/闲谈', 'df3'),
    exact: true
  },
  {
    path: '/blog/tags/游戏',
    component: ComponentCreator('/blog/tags/游戏', 'cb3'),
    exact: true
  },
  {
    path: '/blog/tags/android',
    component: ComponentCreator('/blog/tags/android', 'c11'),
    exact: true
  },
  {
    path: '/markdown-page',
    component: ComponentCreator('/markdown-page', '8ba'),
    exact: true
  },
  {
    path: '/docs',
    component: ComponentCreator('/docs', '653'),
    routes: [
      {
        path: '/docs',
        component: ComponentCreator('/docs', 'b99'),
        routes: [
          {
            path: '/docs',
            component: ComponentCreator('/docs', 'b92'),
            routes: [
              {
                path: '/docs/intro',
                component: ComponentCreator('/docs/intro', '61d'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/tools',
                component: ComponentCreator('/docs/tools', '5d6'),
                exact: true,
                sidebar: "tutorialSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/',
    component: ComponentCreator('/', '939'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
