export default [
  require("C:\\Daniel_blog\\danieltoyama.github.io\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Daniel_blog\\danieltoyama.github.io\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Daniel_blog\\danieltoyama.github.io\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Daniel_blog\\danieltoyama.github.io\\src\\css\\custom.css"),
];
